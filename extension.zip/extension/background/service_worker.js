// Background service worker — keeps backend warm and provides instant data to popup

// Import shared backend URL from config.js (single source of truth)
importScripts('../config.js');

// ─── KEEP-ALIVE: Ping backend every 2 minutes to prevent cold starts ─────────
chrome.runtime.onInstalled.addListener(() => {
  console.log('CP Streak Tracker Extension Installed');

  // Immediately wake the backend + warm DB connection
  wakeBackend();

  // Keep-alive alarm: ping every 2 minutes to prevent backend from sleeping
  chrome.alarms.create('keepBackendAlive', { periodInMinutes: 2 });

  // Full data sync alarm: every 6 hours
  chrome.alarms.create('syncStreakData', { periodInMinutes: 6 * 60 });
});

// Also wake the backend every time Chrome starts
chrome.runtime.onStartup.addListener(() => {
  console.log('Chrome started — waking backend');
  wakeBackend();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'keepBackendAlive') {
    // Lightweight ping — just checks the server is responsive
    try {
      await fetch(`${BACKEND_URL}/health`, { signal: AbortSignal.timeout(5000) });
    } catch {
      // Backend is down — that's okay, we'll retry next alarm
    }
  }

  if (alarm.name === 'syncStreakData') {
    console.log('Running background sync for all platforms...');
    await performBackgroundSync();
  }
});

// ─── WAKE BACKEND: Hit /wake to pre-warm DB pool ─────────────────────────────
async function wakeBackend() {
  try {
    await fetch(`${BACKEND_URL}/wake`, { signal: AbortSignal.timeout(8000) });
    console.log('Backend is warm');
  } catch {
    console.log('Backend wake ping failed — server may be starting');
    // Retry once after 2 seconds
    setTimeout(async () => {
      try {
        await fetch(`${BACKEND_URL}/wake`, { signal: AbortSignal.timeout(8000) });
        console.log('Backend warm on retry');
      } catch {
        console.log('Backend still not responding');
      }
    }, 2000);
  }
}

// ─── PRE-FETCH: Cache streak data so popup opens instantly ────────────────────
async function prefetchStreakData() {
  try {
    const data = await chrome.storage.local.get(['token']);
    if (!data.token) return;

    const res = await fetch(`${BACKEND_URL}/streaks`, {
      headers: { 'Authorization': `Bearer ${data.token}` },
      signal: AbortSignal.timeout(10000)
    });

    if (res.ok) {
      const streakData = await res.json();
      await chrome.storage.local.set({
        cachedStreaks: JSON.stringify(streakData),
        cachedStreaksTimestamp: Date.now()
      });
      console.log('Streak data pre-fetched and cached');
    }
  } catch (err) {
    console.log('Pre-fetch failed:', err.message);
  }
}

// ─── MESSAGE HANDLER: Popup can request wake + data ──────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'wakeAndFetch') {
    // Wake backend + pre-fetch data in parallel
    Promise.all([wakeBackend(), prefetchStreakData()])
      .then(() => sendResponse({ status: 'done' }))
      .catch(() => sendResponse({ status: 'error' }));
    return true; // Keep message channel open for async response
  }

  if (message.action === 'checkBackendHealth') {
    fetch(`${BACKEND_URL}/health`, { signal: AbortSignal.timeout(3000) })
      .then(res => res.json())
      .then(data => sendResponse({ alive: true, data }))
      .catch(() => sendResponse({ alive: false }));
    return true;
  }
});

// ─── BACKGROUND SYNC: Full platform data sync ────────────────────────────────
async function performBackgroundSync() {
  try {
    const data = await chrome.storage.local.get(['token']);
    if (!data.token) {
      console.log('No auth token found, skipping background sync');
      return;
    }

    const response = await fetch(`${BACKEND_URL}/platforms/sync?platform=all`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${data.token}`
      },
      signal: AbortSignal.timeout(30000)
    });

    if (response.ok) {
      console.log('Background sync successful');
      // After sync, pre-fetch the updated streak data
      await prefetchStreakData();
    } else {
      console.error('Background sync failed with status', response.status);
    }
  } catch (error) {
    console.error('Background sync network error:', error);
  }
}
